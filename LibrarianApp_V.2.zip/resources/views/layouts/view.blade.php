@include('layouts.navigation')

@yield('content')



